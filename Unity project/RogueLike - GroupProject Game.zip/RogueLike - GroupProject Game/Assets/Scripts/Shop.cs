﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shop : MonoBehaviour
{
    public static int defPriceMultiplier = 1;
    public static int vitPriceMultiplier = 1;
    public static int strPriceMultiplier = 1;
    
}
